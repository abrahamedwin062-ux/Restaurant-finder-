# Restaurant finder (live, OpenStreetMap)

No API key needed.

1. `npm install && npm start`
2. Open http://localhost:3000

Deploy to Render: Build Command `npm install`, Start Command `npm start`.
Data: © OpenStreetMap contributors (ODbL). Keep the credit line in the page.
